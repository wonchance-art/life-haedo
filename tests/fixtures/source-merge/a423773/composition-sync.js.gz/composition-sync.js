/* Account composition replication. Source sync and public publication stay separate.
 * An optional autoResolve keeps the newest side and stores the other as a recovery copy. */
(function (root, factory) {
  'use strict';
  const api = factory(root); root.HaedoLife ||= {}; root.HaedoLife.CompositionSync = api;
  if (typeof module === 'object' && module.exports) module.exports = api;
})(globalThis, function (root) {
  'use strict';
  // S2: page-lifecycle wiring (sync-lifecycle.js). An older cached page may lack it: the engine
  // then runs its explicit and start-up passes only, until the page reloads.
  const syncLifecycle = () => root.HaedoLife?.SyncLifecycle || (typeof require === 'function' ? require('./sync-lifecycle.js') : null);
  const messages = {
    composition_source_pending: '원문 동기화를 먼저 완료해 주세요. 구성은 이 기기에 보존됩니다.',
    composition_conflict: '두 기기의 구성이 다릅니다. 양쪽 내용을 비교해 주세요.',
    composition_conflict_changed: '비교한 뒤 구성이 바뀌었습니다. 양쪽 내용을 다시 확인해 주세요.',
    remote_revision_mismatch: '같은 서버 버전의 내용이 달라 적용하지 않았습니다.',
    stale_sync_result: '서버 버전이 이전보다 낮거나 현재 요청과 달라 적용하지 않았습니다.',
    remote_missing: '연결된 서버 구성이 없습니다. 자동으로 다시 만들지 않았습니다.',
    sync_paused: '구성 동기화를 다시 시작하는 중입니다.',
    not_enabled: '구성 동기화를 준비하는 중입니다.',
    account_mismatch: '현재 계정의 구성 연결을 확인해 주세요.',
    request_cancelled: '계정 또는 연결이 바뀌어 이전 요청을 적용하지 않았습니다.',
    storage_quota: '저장 공간이 부족합니다. 현재 구성과 복구 사본을 보존한 뒤 다시 시도해 주세요.',
    network_error: '연결을 확인한 뒤 다시 시도해 주세요. 구성과 전송 대기 내용은 보존됩니다.'
  };
  const clone = value => value == null ? value : JSON.parse(JSON.stringify(value));
  const time = value => { const parsed = typeof value === 'string' ? Date.parse(value) : NaN; return Number.isFinite(parsed) ? parsed : null; };
  // Latest edit wins. The local edit time is recorded with each composition save;
  // the server row carries its own write time. Unknown local time yields to the server.
  // The remote side's own edit time travels in its payload (data.editedAt); older servers and
  // rows written before that fall back to the server write time.
  function latest({ remote, editedAt }) {
    const local = time(editedAt), server = time(remote?.data?.editedAt) ?? time(remote?.updated_at);
    if (local === null) return 'remote';
    return server !== null && server >= local ? 'remote' : 'local';
  }
  const fault = code => Object.assign(new Error(messages[code] || messages.network_error), { code });
  function create({ storage, sourceSync, auth = root.HaedoAuth,
    remote = root.HaedoLife?.CompositionRemote?.create({ auth }), errorCleaner = null,
    resolutionChoices = ['local', 'remote'], sendResolution = choice => choice === 'local', polling = true,
    initialReceive = null, autoResolve = undefined } = {}) {
    if (!storage?.account || !sourceSync || !auth || !remote) throw fault('account_mismatch');
    // Compositions (whose storage records local edit times) default to latest-wins.
    // Other domains on this engine keep their own explicit choice unless they pass one.
    const compositionDomain = typeof storage.readWorkbenchEditedAt === 'function';
    if (autoResolve === undefined) autoResolve = compositionDomain ? latest : null;
    // Without the account library nothing else enrols a workspace: start its composition sync
    // as soon as its originals sync for this account (no per-workspace opt-in).
    const autoEnable = compositionDomain;
    const owner = storage.account, watches = new Map(), timers = new Map(), locks = new Map(), generations = new Map(), listeners = new Set();
    let disposed = false, started = false, wiring = null, refreshing = false, refreshAgain = false, unlistenSources = null, parked = false;
    // Between a persisted pagehide and its pageshow the page sits in the back/forward cache:
    // starting work there evicts it, and nothing begun then may stand in for the resumed page's
    // own account check. A cached page resumes on the regular poll.
    const pagehide = event => { if (event?.persisted) { parked = true; refreshAgain = false; for (const timer of timers.values()) root.clearTimeout(timer); timers.clear(); } };
    const pageshow = event => { if (event?.persisted) parked = false; };
    const sameAccount = value => value?.userId === owner.userId && value?.projectUrl === owner.projectUrl;
    function guard(context) {
      if (disposed || !sameAccount(auth.getAccount()) || context &&
          (context.generation !== (generations.get(context.workspaceId) || 0) || context.authEpoch !== auth.epoch)) throw fault('request_cancelled');
    }
    const context = workspaceId => { guard(); return { workspaceId, generation: generations.get(workspaceId) || 0, authEpoch: auth.epoch }; };
    const binding = workspaceId => ({ projectUrl: owner.projectUrl, userId: owner.userId, remoteId: workspaceId });
    function emit(workspaceId, extra = null) { if (!disposed) for (const listener of [...listeners]) { try { listener({ workspaceId, ...(extra || {}) }); } catch (_) {} } }
    function clean(error) {
      if (errorCleaner) return errorCleaner(error);
      if (messages[error?.code]) return fault(error.code);
      return root.HaedoLife?.CompositionRemote?.clean(error) || fault('network_error');
    }
    function serial(ctx, task) {
      const key = ctx.workspaceId + '|' + ctx.generation + '|' + ctx.authEpoch;
      const previous = locks.get(key) || Promise.resolve();
      const pending = previous.catch(() => {}).then(() => { guard(ctx); return task(); });
      locks.set(key, pending);
      pending.finally(() => { if (locks.get(key) === pending) locks.delete(key); }).catch(() => {});
      return pending;
    }
    async function getState(workspaceId) {
      const ctx = context(workspaceId);
      const state = await storage.getCompositionState(workspaceId); guard(ctx);
      return state ? { ...clone(state), status: state.enabled ? state.status : 'paused' } : { workspaceId, enabled: false, status: 'not_enabled', conflict: null, error: null, lastRecoveryId: null };
    }
    // One source head check per sync pass (2026-11-04 startup latency): inside run(), a later
    // call (enable → run, the read row's source_revision) asks the server again only when the
    // local source is no longer clean or does not hold the revision it needs. A newer server
    // source is not required here, only one at least as new as the row's. compare() and
    // resolve() themselves still check every time.
    const ready = (state, minimum) => state.enabled && state.status === 'synced' && sameAccount(state.binding) && state.remoteRevision >= minimum;
    async function sources(ctx, minimum = 1) {
      guard(ctx);
      const initial = await sourceSync.getState(ctx.workspaceId); guard(ctx);
      if (!initial.enabled || !sameAccount(initial.binding)) throw fault('composition_source_pending');
      // A skipped check reuses the state just read (2026-11-04: one status read less per skipped check).
      // Nothing is awaited between that read and here. The old second read was a new transaction and
      // could see a write another tab committed in between; that gap only adds a race that the storage's
      // atomic source check and the pass's one retry already cover.
      const skip = ctx.reuseSource && ctx.sourceChecked && ready(initial, minimum);
      if (skip) ctx.sourceSkipped = true;
      else { await sourceSync.syncNow(ctx.workspaceId, { headIfClean: true }); guard(ctx); }
      const current = skip ? initial : await sourceSync.getState(ctx.workspaceId); guard(ctx);
      if (!ready(current, minimum)) throw fault('composition_source_pending');
      ctx.sourceChecked = true;
      return current;
    }
    async function checkedState(ctx) {
      const state = await storage.getCompositionState(ctx.workspaceId); guard(ctx);
      if (!state) throw fault('not_enabled');
      if (!sameAccount(state.binding) || state.binding.remoteId !== ctx.workspaceId) throw fault('account_mismatch');
      if (!state.enabled) throw fault('sync_paused');
      return state;
    }
    async function conflict(ctx, row) {
      if (row) await sources(ctx, row.source_revision);
      guard(ctx); await storage.setCompositionConflict(ctx.workspaceId, binding(ctx.workspaceId), row); guard(ctx);
      emit(ctx.workspaceId); return getState(ctx.workspaceId);
    }
    // Record the conflict first. With autoResolve the domain picks the newer side
    // and resolve* stores the other side as a recovery copy in the same transaction.
    async function settle(ctx, row) {
      await conflict(ctx, row);
      if (!autoResolve || !row) return false;
      const snapshot = await storage.readWorkbenchSnapshot(ctx.workspaceId); guard(ctx);
      const editedAt = typeof storage.readWorkbenchEditedAt === 'function' ? await storage.readWorkbenchEditedAt(ctx.workspaceId) : null; guard(ctx);
      const choice = await autoResolve({ workspaceId: ctx.workspaceId, local: clone(snapshot.workbench), remote: clone(row), editedAt }); guard(ctx);
      if (!resolutionChoices.includes(choice)) return false;
      try {
        const result = await storage.resolveCompositionSync(ctx.workspaceId, binding(ctx.workspaceId), {
          choice, expectedLocalRevision: snapshot.workbench.revision, remoteRow: row }); guard(ctx);
        const recoveryId = result?.recoveryId || result?.recoveryStageId || null;
        // An empty/default losing side keeps no recovery copy, so there is nothing to announce.
        emit(ctx.workspaceId, recoveryId ? { autoResolved: true, choice, recoveryId } : { resolved: choice });
        return true;
      } catch (error) {
        // A newer local edit or remote head arrived; the next pass reads both again.
        if (/conflict_changed$/.test(error?.code || '')) { guard(ctx); return true; }
        throw error;
      }
    }
    async function send(ctx, outbox) {
      guard(ctx);
      const request = { workspaceId: ctx.workspaceId, ...clone(outbox) }, operationId = request.operationId;
      const expectedRevision = request.expectedRevision;
      const reply = await remote.write(request); guard(ctx);
      if (reply.status === 'stored') {
        await storage.ackCompositionSync(ctx.workspaceId, binding(ctx.workspaceId), operationId, reply.revision); guard(ctx);
        emit(ctx.workspaceId); return true;
      }
      const row = reply.status === 'missing' ? null : await remote.read(ctx.workspaceId); guard(ctx);
      if (reply.status === 'conflict' && expectedRevision === 0 && row && initialReceive) {
        await sources(ctx, row.source_revision);
        // Concurrent first writers may have sent the same pristine empty model.
        // Only the domain's atomic check may clear that exact initial outbox;
        // any later edit or differing payload keeps the ordinary conflict path.
        const received = await initialReceive(ctx.workspaceId, binding(ctx.workspaceId), clone(row), { outboxOperationId: operationId }); guard(ctx);
        if (received?.status === 'stored') { emit(ctx.workspaceId); return true; }
      }
      await conflict(ctx, row); return false;
    }
    async function run(ctx) {
      ctx.reuseSource = true;
      try {
        await checkedState(ctx); await sources(ctx);
        for (let pass = 0; pass < 8; pass++) {
          const state = await checkedState(ctx);
          if (state.conflict) { const row = await remote.read(ctx.workspaceId); guard(ctx); if (await settle(ctx, row)) continue; return getState(ctx.workspaceId); }
          // A lost response is resolved by replaying the same durable operation before reads.
          if (state.outbox) { if (await send(ctx, state.outbox) || autoResolve) continue; return getState(ctx.workspaceId); }
          const row = await remote.read(ctx.workspaceId); guard(ctx);
          if (!row && state.remoteRevision > 0) return conflict(ctx, null);
          if (row) {
            await sources(ctx, row.source_revision);
            if (!state.remoteRevision) {
              if (initialReceive) {
                const received = await initialReceive(ctx.workspaceId, binding(ctx.workspaceId), clone(row)); guard(ctx);
                if (received?.status === 'stored') continue;
              }
              if (await settle(ctx, row)) continue;
              return getState(ctx.workspaceId);
            }
            const applied = await storage.applyCompositionRemote(ctx.workspaceId, binding(ctx.workspaceId), row); guard(ctx);
            if (applied.status === 'conflict') { if (await settle(ctx, row)) continue; return getState(ctx.workspaceId); }
          }
          const outbox = await storage.prepareCompositionUpload(ctx.workspaceId, binding(ctx.workspaceId)); guard(ctx);
          if (outbox) { if (await send(ctx, outbox) || autoResolve) continue; return getState(ctx.workspaceId); }
          await storage.setCompositionError(ctx.workspaceId, binding(ctx.workspaceId), null); guard(ctx);
          emit(ctx.workspaceId); return getState(ctx.workspaceId);
        }
        schedule(ctx.workspaceId); return getState(ctx.workspaceId);
      } catch (error) {
        guard(ctx);
        // A skipped check trusted the stored source status. A local source write that leaves it
        // stale (a material-continuity install raises the bundle revision) is refused here by
        // storage; check with the server once more and retry, as every call did before.
        if (error?.code === 'composition_source_pending' && ctx.sourceSkipped && !ctx.sourceRetried) {
          Object.assign(ctx, { sourceRetried: true, sourceChecked: false, sourceSkipped: false });
          return run(ctx);
        }
        const safe = clean(error);
        if (!['sync_paused', 'not_enabled', 'request_cancelled'].includes(safe.code)) {
          await storage.setCompositionError(ctx.workspaceId, binding(ctx.workspaceId), { code: safe.code, message: safe.message }).catch(() => {});
          guard(ctx); emit(ctx.workspaceId);
        }
        throw safe;
      }
    }
    async function syncNow(workspaceId) { const ctx = context(workspaceId); return serial(ctx, () => run(ctx)); }
    function schedule(workspaceId) {
      if (disposed || parked || timers.has(workspaceId)) return;
      const timer = root.setTimeout(() => { timers.delete(workspaceId); syncNow(workspaceId).catch(() => {}); }, 500);
      timer?.unref?.(); timers.set(workspaceId, timer);
    }
    function watch(workspaceId) {
      if (watches.has(workspaceId)) return;
      watches.set(workspaceId, storage.subscribe(workspaceId, event => {
        if (disposed) return;
        if (event.type === 'workbench_changed') { emit(workspaceId); schedule(workspaceId); }
        else if (event.type === 'composition_sync_changed') emit(workspaceId);
      }));
    }
    async function enable(workspaceId) {
      const ctx = context(workspaceId);
      return serial(ctx, async () => {
        await sources(ctx);
        // Probe installation before recording consent. Missing schema is not an empty success.
        await remote.read(workspaceId); guard(ctx);
        await storage.bindCompositionSync(workspaceId, binding(workspaceId)); guard(ctx);
        watch(workspaceId); emit(workspaceId); return run(ctx);
      });
    }
    async function pause(workspaceId) {
      const ctx = context(workspaceId);
      generations.set(workspaceId, ctx.generation + 1);
      ctx.generation++;
      root.clearTimeout(timers.get(workspaceId)); timers.delete(workspaceId);
      const previous = await storage.getCompositionState(workspaceId); guard(ctx);
      if (previous) { await storage.pauseCompositionSync(workspaceId, binding(workspaceId)); guard(ctx); }
      emit(workspaceId); return getState(workspaceId);
    }
    async function compare(workspaceId) {
      const ctx = context(workspaceId);
      return serial(ctx, async () => {
        const state = await checkedState(ctx);
        if (!state.conflict) throw fault('composition_conflict_changed');
        await sources(ctx);
        const row = await remote.read(workspaceId); guard(ctx);
        await conflict(ctx, row);
        const snapshot = await storage.readWorkbenchSnapshot(workspaceId); guard(ctx);
        return { local: snapshot.workbench, remote: row, bundle: snapshot.bundle, expectedLocalRevision: snapshot.workbench.revision, expectedRemoteRevision: row?.revision ?? null };
      });
    }
    async function resolve(workspaceId, choice, expected) {
      const reviewedLocalRevision = expected?.expectedLocalRevision, reviewedRemoteRevision = expected?.expectedRemoteRevision;
      const ctx = context(workspaceId);
      return serial(ctx, async () => {
        const state = await checkedState(ctx);
        if (!resolutionChoices.includes(choice) || !state.conflict || state.conflict.missing ||
            state.conflict.remoteRevision !== reviewedRemoteRevision) throw fault('composition_conflict_changed');
        await sources(ctx);
        const row = await remote.read(workspaceId); guard(ctx);
        if (!row) { await conflict(ctx, null); throw fault('remote_missing'); }
        if (row.revision !== reviewedRemoteRevision) { await conflict(ctx, row); throw fault('composition_conflict_changed'); }
        await sources(ctx, row.source_revision);
        const result = await storage.resolveCompositionSync(workspaceId, binding(workspaceId), {
          choice, expectedLocalRevision: reviewedLocalRevision, remoteRow: row }); guard(ctx);
        emit(workspaceId);
        if (sendResolution(choice, result)) {
          try { await run(ctx); } catch (error) { result.syncError = { code: error.code, message: error.message }; }
          guard(ctx);
        }
        return result;
      });
    }
    async function automatic() {
      if (disposed || parked || root.document?.visibilityState === 'hidden') { refreshAgain = false; return; }
      if (refreshing) { refreshAgain = true; return; }
      refreshing = true;
      // A source event can arrive after its old state was read but before this scan finishes.
      // Coalesce those wakeups without a recursive call or another timer. enable() also emits
      // source events itself: a failed probe waits for the next independent wakeup instead of
      // retrying its own event forever. A stale source-pending result gets one fresh attempt;
      // repeated pending results wait for the next independent wakeup too.
      const failedEnables = new Set(), retriedSources = new Set();
      try {
        do {
          refreshAgain = false;
          guard(); const rows = await storage.listWorkspaces(); guard();
          for (const row of rows) {
            const state = await getState(row.workspaceId);
            if (state.enabled) { watch(row.workspaceId); schedule(row.workspaceId); }
            else if (autoEnable && !failedEnables.has(row.workspaceId)) {
              const source = await sourceSync.getState(row.workspaceId); guard();
              if (source?.enabled && source.status === 'synced' && sameAccount(source.binding)) await enable(row.workspaceId).catch(error => {
                if (error?.code === 'composition_source_pending' && !retriedSources.has(row.workspaceId)) retriedSources.add(row.workspaceId);
                else failedEnables.add(row.workspaceId);
              });
            }
          }
        } while (refreshAgain && !disposed && !parked && root.document?.visibilityState !== 'hidden');
      } catch (_) { /* State stays durable; an explicit retry gives the current error. */ }
      finally { refreshing = false; refreshAgain = false; }
    }
    function start() {
      guard(); if (started) return; started = true;
      wiring = syncLifecycle()?.attach(root, {
        listen: [['window', 'online', automatic], ['window', 'focus', automatic], ['document', 'visibilitychange', automatic],
          ['window', 'pagehide', pagehide], ['window', 'pageshow', pageshow]],
        poll: polling ? [30000, automatic] : null,
      }) || null;
      unlistenSources = sourceSync.subscribe(event => {
        if (!event.workspaceId) return;
        if (watches.has(event.workspaceId)) { if (![...locks.keys()].some(key => key.startsWith(event.workspaceId + '|'))) schedule(event.workspaceId); }
        else if (autoEnable) automatic();
      });
      automatic();
    }
    function dispose() {
      if (disposed) return; disposed = true; refreshAgain = false;
      for (const timer of timers.values()) root.clearTimeout(timer);
      for (const stop of watches.values()) stop();
      timers.clear(); watches.clear(); listeners.clear();
      wiring?.detach(); wiring = null; unlistenSources?.();
      remote.dispose?.();
    }
    function subscribe(listener) { guard(); listeners.add(listener); return () => listeners.delete(listener); }
    // The automatic-resolution notice persists in the state record until acknowledged.
    async function dismissNotice(workspaceId) {
      const ctx = context(workspaceId);
      if (typeof storage.dismissCompositionNotice === 'function') { await storage.dismissCompositionNotice(workspaceId); guard(ctx); }
      emit(workspaceId); return getState(workspaceId);
    }
    return Object.freeze({ start, getState, enable, pause, syncNow, compare, resolve, dismissNotice, subscribe, dispose });
  }
  return Object.freeze({ create, latest });
});
