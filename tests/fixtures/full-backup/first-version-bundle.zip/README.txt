해도 전체 백업

만든 시각: 2026-11-01T14:03:30.096Z
앱 버전: 확인 불가
상태: 모든 항목 포함

이 ZIP은 하나의 형식이 아닙니다. 아래 파일마다 기존 백업 형식을 그대로 담았습니다.
복원: 해도 → 설정 → 백업·복원 → 복원에서 이 ZIP을 고르면 새 자료공간 사본으로 복원합니다. 기존 자료는 바뀌지 않습니다.
각 파일은 원래 화면(자료·구성 백업, 컬렉션, 9칸, 사진 글, 연표 목록)에서도 따로 복원할 수 있습니다.

자료공간
  01 내 자료
  02 두 번째 자료공간

파일 (경로 · 종류 · 형식/버전 · 개수 · 바이트 · SHA-256)
  workspaces/01/library.json
    자료·구성 · life-material-library-backup-v1 v1 · 자료 1 · 원문 버전 2 · 발췌 1 · 묶음 1 · 폴더 1 · 5164 · 62214da77f3795fd0f6bd3745641824e4e57b2a3ceab7940ead813544c5f079d
  workspaces/01/collection.json
    컬렉션 · life-collection-backup-v1 v1 · 항목 1 · 446 · 2c7f66bddd780cb0a5f29a03758ff5fca9e22d1fa9ea3ad70a587255917581cd
  workspaces/01/nine-boards.json
    9칸 구성 · life-nine-board-backup-v2 v2 · 구성 1 · 항목 1 · 1380 · 81fc2ca2b51363acd37f74a1145d37baba93fcdbd295f60e1f4f8a5807c483bd
  workspaces/01/photo-posts/8edb352c-5fd9-4f0d-9709-e36caf0ef475.zip
    사진 글 · life-photo-post-backup-v2 v2 · 글 1 · 사진 2 · HEIC 보기용 1 · 13440 · f72dfc0ef93d3c7a7dadcce8c59ab193b8e47fb09d165ecf954e0d9096237537
  workspaces/02/library.json
    자료·구성 · life-workbench-backup-v1 v1 · 자료 1 · 원문 버전 1 · 발췌 1 · 3168 · d135ff75c7716b53fa7bca7c2da5dfcafa404e4264396e637ea6962c0d492998
  workspaces/02/collection.json
    컬렉션 · life-collection-backup-v1 v1 · 항목 0 · 102 · 5517e0fc7db78e9643108ffe1309e25858a09c2dd157528b2e3f203194802d66
  workspaces/02/nine-boards.json
    9칸 구성 · life-nine-board-backup-v1 v1 · 구성 0 · 항목 0 · 59 · ab73cbaf65b674d850dc1f911852dfeff861dfa8fbc6cc7e0f52fd02c839890d
  workspaces/02/photo-posts/cc11be30-0155-44f1-a684-784ae8631d89.zip
    사진 글 · life-photo-post-backup-v2 v2 · 글 1 · 263 · 4a233169027b426e92981d21ec62ba72ad1d3cfb9184501c6436c5790d09102d
  account-documents.json
    계정 설정·기록 문서 · haedo-account-documents-v1 v1 · 문서 2 · 1357 · b61903ec71a06cec6462256227624563e54f64c459c242bbedb8f4b5e74d3e61
  timeline-goals-habits.json
    연표·목표·습관 · haedo-platform-backup-v1 v1 · 연표 1 · 목표 1 · 439 · af912d96e557328d43ccc12951b07e6fdba82d4e412ac574aed8127138029bdc
